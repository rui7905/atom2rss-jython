# Test case for PR#183; print of a recursive PyStringMap causes a JVM stack
# overflow.

g = globals()
print g
